# Asterisk Auto-Dialer Setup Guide

## Complete Installation & Configuration

### Step 1: Install Asterisk

```bash
# Make the installation script executable
chmod +x install_asterisk.sh

# Run the installation (this will take 15-30 minutes)
sudo ./install_asterisk.sh
```

### Step 2: Configure Asterisk

```bash
# Backup original configuration files
sudo cp /etc/asterisk/pjsip.conf /etc/asterisk/pjsip.conf.backup
sudo cp /etc/asterisk/extensions.conf /etc/asterisk/extensions.conf.backup

# Copy your configuration files
sudo cp pjsip.conf /etc/asterisk/pjsip.conf
sudo cp extensions.conf /etc/asterisk/extensions.conf

# Set proper ownership
sudo chown asterisk:asterisk /etc/asterisk/pjsip.conf
sudo chown asterisk:asterisk /etc/asterisk/extensions.conf
```

### Step 3: Start Asterisk

```bash
# Enable Asterisk to start on boot
sudo systemctl enable asterisk

# Start Asterisk service
sudo systemctl start asterisk

# Check status
sudo systemctl status asterisk
```

### Step 4: Verify SIP Registration

```bash
# Connect to Asterisk CLI
sudo asterisk -rvvv

# In the Asterisk CLI, check registration status:
pjsip show registrations

# You should see your trunk registered to 87.120.187.60
# Press Ctrl+C to exit the CLI
```

### Step 5: Setup Auto-Dialer Script

```bash
# Make the Python script executable
chmod +x autodialer.py

# Install Python (if not already installed)
sudo apt install python3 -y

# Create necessary directories
sudo mkdir -p /var/log/asterisk
sudo touch /var/log/asterisk/autodialer.log
sudo chown asterisk:asterisk /var/log/asterisk/autodialer.log
```

### Step 6: Run Your First Test Call

```bash
# Test with a single call
sudo python3 autodialer.py

# Choose option 2 (Dial single number)
# Enter your test details:
# - Destination: 442080725001
# - CLI: 447985019847
# - Duration: 5
```

### Step 7: Batch Dialing from CSV

```bash
# Use the provided calls.csv or create your own
# Format: destination;cli;duration

# Run batch dialing
sudo python3 autodialer.py

# Choose option 1 (Dial from CSV file)
# Enter: calls.csv
# Enter delay: 2 (seconds between calls)
```

## Call File Format Explained

The auto-dialer creates call files with this format:

```
Channel: Local/s@autodialer
Callerid: <CLI>
MaxRetries: 2
RetryTime: 60
WaitTime: 45
Context: autodialer
Extension: s
Priority: 1
SetVar: DESTINATION=<phone_number>
SetVar: CUSTOM_CLI=<caller_id>
SetVar: CALL_DURATION=<seconds>
Archive: yes
```

## CSV File Format

Create a CSV file (semicolon-separated):

```
destination;caller_id;duration_in_seconds
442080725001;447985019847;5
442080725010;447819001928;10
442080725002;442080725111;15
```

## Advanced Usage

### Python Script Integration

```python
#!/usr/bin/env python3
from autodialer import AutoDialer

# Create dialer instance
dialer = AutoDialer()

# Single call
dialer.dial_single(
    destination="442080725001",
    cli="447985019847",
    duration=5
)

# Batch calls
calls = [
    ("442080725001", "447985019847", 5),
    ("442080725010", "447819001928", 10),
]
dialer.dial_list(calls, delay_between_calls=3)

# From CSV
dialer.dial_from_csv("calls.csv", delay_between_calls=2)
```

### Scheduling Calls with Cron

```bash
# Edit crontab
crontab -e

# Add a scheduled job (example: daily at 9 AM)
0 9 * * * /usr/bin/python3 /home/youruser/autodialer.py << EOF
1
/home/youruser/calls.csv
2
EOF
```

## Monitoring & Troubleshooting

### Check Asterisk Logs

```bash
# Real-time log monitoring
sudo tail -f /var/log/asterisk/messages

# Auto-dialer specific logs
sudo tail -f /var/log/asterisk/autodialer.log

# CDR (Call Detail Records)
sudo tail -f /var/log/asterisk/cdr-csv/Master.csv
```

### Common Issues

**1. Registration Failed**
```bash
# Check PJSIP status
sudo asterisk -rx "pjsip show registrations"

# Verify credentials in /etc/asterisk/pjsip.conf
# Check firewall: UDP port 5060 must be open
sudo ufw allow 5060/udp
```

**2. Calls Not Initiating**
```bash
# Check spool directory permissions
sudo ls -la /var/spool/asterisk/outgoing/

# Should be owned by asterisk:asterisk
sudo chown -R asterisk:asterisk /var/spool/asterisk/
```

**3. Permission Denied on Call Files**
```bash
# Run dialer with sudo
sudo python3 autodialer.py

# Or add your user to asterisk group
sudo usermod -aG asterisk $USER
```

**4. Audio Issues**
```bash
# Check codec compatibility in pjsip.conf
# Allowed codecs: ulaw, alaw, gsm
# Contact your trunk provider for supported codecs
```

## Firewall Configuration

```bash
# Allow SIP signaling
sudo ufw allow 5060/udp

# Allow RTP media (if needed)
sudo ufw allow 10000:20000/udp

# Enable firewall
sudo ufw enable
```

## Security Recommendations

1. **Change Default Passwords**: Update the trunk password in pjsip.conf
2. **Restrict Access**: Use firewall rules to limit connections
3. **Monitor Logs**: Regularly check for unusual activity
4. **Fail2Ban**: Consider installing fail2ban for brute-force protection

```bash
sudo apt install fail2ban -y
```

## Performance Tuning

For high-volume dialing:

```bash
# Edit /etc/asterisk/asterisk.conf
sudo nano /etc/asterisk/asterisk.conf

# Increase max calls
maxcalls = 500

# Restart Asterisk
sudo systemctl restart asterisk
```

## Call Flow Diagram

```
1. Python Script creates call file → /tmp/asterisk_calls/
2. Script moves file → /var/spool/asterisk/outgoing/
3. Asterisk picks up file and processes it
4. Registers to trunk (87.120.187.60) as user 'parked'
5. Originates call with custom CLI
6. Maintains call for specified duration
7. Hangs up
8. Archives call file
```

## Useful Asterisk CLI Commands

```bash
# Connect to Asterisk CLI
sudo asterisk -rvvv

# Show active calls
core show channels

# Show registrations
pjsip show registrations

# Show endpoints
pjsip show endpoints

# Reload configuration
pjsip reload

# Enable debug
pjsip set logger on
```

## Support & Troubleshooting

Check logs in this order:
1. `/var/log/asterisk/autodialer.log` - Script logs
2. `/var/log/asterisk/messages` - Asterisk main log
3. `/var/log/asterisk/full` - Detailed Asterisk log
4. `sudo asterisk -rvvv` - Real-time CLI

## Next Steps

1. Test with small batches first
2. Monitor call completion rates
3. Adjust retry settings in call files if needed
4. Scale up gradually
5. Implement error handling for failed calls
6. Set up CDR analysis for reporting

## File Locations Reference

- Configuration: `/etc/asterisk/`
- Logs: `/var/log/asterisk/`
- Spool (outgoing calls): `/var/spool/asterisk/outgoing/`
- Call file temp: `/tmp/asterisk_calls/`
- Script: `~/autodialer.py`
- CSV: `~/calls.csv`
