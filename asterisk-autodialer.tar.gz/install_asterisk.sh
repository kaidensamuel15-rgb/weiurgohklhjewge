#!/bin/bash

# Asterisk Auto-Dialer Installation Script
# Ubuntu Server

echo "=================================="
echo "Asterisk Auto-Dialer Installation"
echo "=================================="

# Update system
echo "[1/5] Updating system packages..."
sudo apt update
sudo apt upgrade -y

# Install dependencies
echo "[2/5] Installing dependencies..."
sudo apt install -y build-essential wget libssl-dev libncurses5-dev \
    libnewt-dev libxml2-dev linux-headers-$(uname -r) libsqlite3-dev \
    uuid-dev git curl python3 python3-pip

# Download and install Asterisk
echo "[3/5] Downloading Asterisk 20 LTS..."
cd /usr/src
sudo wget https://downloads.asterisk.org/pub/telephony/asterisk/asterisk-20-current.tar.gz
sudo tar -xzvf asterisk-20-current.tar.gz
cd asterisk-20*/

# Install prerequisites
echo "[4/5] Installing Asterisk prerequisites..."
sudo contrib/scripts/get_mp3_source.sh
sudo contrib/scripts/install_prereq install

# Configure and compile
echo "[5/5] Compiling Asterisk (this may take 10-20 minutes)..."
sudo ./configure --with-jansson-bundled
sudo make menuselect.makeopts
sudo menuselect/menuselect --enable app_macro --enable CORE-SOUNDS-EN-WAV \
    --enable MOH-OPSOUND-WAV --enable EXTRA-SOUNDS-EN-WAV menuselect.makeopts
sudo make -j$(nproc)
sudo make install
sudo make samples
sudo make config
sudo ldconfig

# Create asterisk user
echo "Creating asterisk user..."
sudo groupadd asterisk
sudo useradd -r -d /var/lib/asterisk -g asterisk asterisk
sudo usermod -aG audio,dialout asterisk

# Set permissions
sudo chown -R asterisk:asterisk /etc/asterisk
sudo chown -R asterisk:asterisk /var/{lib,log,spool}/asterisk
sudo chown -R asterisk:asterisk /usr/lib/asterisk

# Configure Asterisk to run as asterisk user
sudo sed -i 's/#AST_USER="asterisk"/AST_USER="asterisk"/' /etc/default/asterisk
sudo sed -i 's/#AST_GROUP="asterisk"/AST_GROUP="asterisk"/' /etc/default/asterisk

echo ""
echo "=================================="
echo "Installation Complete!"
echo "=================================="
echo "Next steps:"
echo "1. Configure SIP trunk in /etc/asterisk/pjsip.conf"
echo "2. Configure dialplan in /etc/asterisk/extensions.conf"
echo "3. Run: sudo systemctl enable asterisk"
echo "4. Run: sudo systemctl start asterisk"
echo "=================================="
