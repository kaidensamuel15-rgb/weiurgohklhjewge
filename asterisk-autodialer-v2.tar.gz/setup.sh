#!/bin/bash

# Setup script to configure Asterisk for auto-dialing
# Run this AFTER install_asterisk.sh completes

echo "=================================="
echo "Configuring Asterisk Auto-Dialer"
echo "=================================="

# Backup existing configs
echo "Backing up existing configurations..."
cp /etc/asterisk/pjsip.conf /etc/asterisk/pjsip.conf.backup 2>/dev/null
cp /etc/asterisk/extensions.conf /etc/asterisk/extensions.conf.backup 2>/dev/null

# Copy configuration files
echo "Installing pjsip.conf..."
cp pjsip.conf /etc/asterisk/pjsip.conf

echo "Installing extensions.conf..."
cp extensions.conf /etc/asterisk/extensions.conf

# Set proper ownership
chown asterisk:asterisk /etc/asterisk/pjsip.conf
chown asterisk:asterisk /etc/asterisk/extensions.conf

# Copy auto-dialer script
echo "Installing auto-dialer script..."
cp autodialer.py /root/autodialer.py
chmod +x /root/autodialer.py

# Copy sample CSV
echo "Installing sample CSV..."
cp calls.csv /root/calls.csv

# Create log file
touch /var/log/asterisk/autodialer.log
chown asterisk:asterisk /var/log/asterisk/autodialer.log

# Start Asterisk
echo "Starting Asterisk..."
systemctl enable asterisk
systemctl restart asterisk

# Wait for Asterisk to start
echo "Waiting for Asterisk to initialize..."
sleep 5

# Check registration
echo ""
echo "=================================="
echo "Checking SIP Registration..."
echo "=================================="
asterisk -rx "pjsip show registrations"

echo ""
echo "=================================="
echo "Setup Complete!"
echo "=================================="
echo ""
echo "To test the auto-dialer:"
echo "  python3 /root/autodialer.py"
echo ""
echo "To monitor calls:"
echo "  asterisk -rvvvv"
echo ""
echo "To check registration:"
echo "  asterisk -rx 'pjsip show registrations'"
echo ""
echo "Sample CSV is located at: /root/calls.csv"
echo "=================================="
