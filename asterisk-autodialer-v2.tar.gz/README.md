# Asterisk Auto-Dialer - Complete Package
## Working Version - Tested and Verified

This package contains a fully working Asterisk-based auto-dialer that:
- Registers to a SIP trunk
- Places outbound calls with custom Caller ID
- Maintains calls for a specified duration
- Automatically hangs up after duration expires
- No duplicate calls

---

## 📦 Package Contents

- `install_asterisk.sh` - Asterisk 20 installation script
- `setup.sh` - Configuration deployment script
- `pjsip.conf` - SIP trunk configuration
- `extensions.conf` - Dialplan configuration
- `autodialer.py` - Python auto-dialer script
- `calls.csv` - Sample call list
- `README.md` - This file

---

## 🚀 Quick Start Installation

### Step 1: Install Asterisk (15-30 minutes)

```bash
chmod +x install_asterisk.sh
sudo ./install_asterisk.sh
```

This will:
- Update system packages
- Install dependencies
- Download and compile Asterisk 20
- Create asterisk user
- Set proper permissions

**Note:** Compilation takes 10-20 minutes depending on your CPU.

### Step 2: Configure Auto-Dialer

**IMPORTANT:** Before running setup, edit `pjsip.conf` to update your trunk credentials:

```bash
# Edit pjsip.conf and update these lines:
# username=YOUR_USERNAME
# password=YOUR_PASSWORD
# server_uri=sip:YOUR_SERVER:5060
```

Then run setup:

```bash
chmod +x setup.sh
sudo ./setup.sh
```

This will:
- Deploy PJSIP configuration
- Deploy dialplan
- Install auto-dialer script
- Start Asterisk
- Verify registration

### Step 3: Verify Registration

```bash
asterisk -rx "pjsip show registrations"
```

You should see:
```
parked-trunk/sip:87.120.187.60:5060    parked-auth    Registered
```

---

## 📞 Using the Auto-Dialer

### Option 1: Interactive Menu

```bash
python3 /root/autodialer.py
```

Choose from:
1. Dial from CSV file
2. Dial single number
3. Dial example batch
4. Exit

### Option 2: From CSV File

Create a CSV file with format: `destination;cli;duration`

Example `calls.csv`:
```
442080725001;447985019847;5
442080725010;447819001928;10
442080725002;442080725111;15
```

Then:
```bash
python3 /root/autodialer.py
# Choose option 1
# Enter: /root/calls.csv
# Enter delay: 2
```

### Option 3: Programmatic Usage

```python
#!/usr/bin/env python3
from autodialer import AutoDialer

dialer = AutoDialer()

# Single call
dialer.dial_single(
    destination="442080725001",
    cli="447985019847",
    duration=5
)

# Batch calls
calls = [
    ("442080725001", "447985019847", 5),
    ("442080725010", "447819001928", 10),
]
dialer.dial_list(calls, delay_between_calls=2)

# From CSV
dialer.dial_from_csv("/root/calls.csv", delay_between_calls=2)
```

---

## 📊 Monitoring

### Real-time Call Monitoring

```bash
asterisk -rvvvv
```

Commands in Asterisk CLI:
- `core show channels` - Show active calls
- `pjsip show registrations` - Check trunk registration
- `pjsip show endpoints` - Show endpoint status
- `dialplan show autodialer` - View dialplan

### Log Files

```bash
# Auto-dialer log
tail -f /var/log/asterisk/autodialer.log

# Asterisk messages
tail -f /var/log/asterisk/messages

# Full debug log
tail -f /var/log/asterisk/full
```

### Check Active Calls

```bash
asterisk -rx "core show channels"
```

---

## ⚙️ Configuration

### Trunk Configuration (pjsip.conf)

Located at: `/etc/asterisk/pjsip.conf`

Key settings:
```ini
[parked-auth]
username=parked          # Your SIP username
password=dickhead        # Your SIP password

[parked-trunk]
server_uri=sip:87.120.187.60:5060    # Your SIP server
```

After changes:
```bash
asterisk -rx "pjsip reload"
```

### Dialplan (extensions.conf)

Located at: `/etc/asterisk/extensions.conf`

The `[autodialer]` context handles outbound calls.

After changes:
```bash
asterisk -rx "dialplan reload"
```

---

## 🛠️ Troubleshooting

### Registration Failed

```bash
# Check logs
asterisk -rx "pjsip show registrations"

# Enable debug
asterisk -rx "pjsip set logger on"
tail -f /var/log/asterisk/messages
```

Common issues:
- Wrong credentials in pjsip.conf
- Firewall blocking port 5060
- Network connectivity

### Calls Not Initiating

```bash
# Check spool directory
ls -la /var/spool/asterisk/outgoing/

# Check file ownership (should be asterisk:asterisk)
# If files are stuck, fix ownership:
sudo chown asterisk:asterisk /var/spool/asterisk/outgoing/*
```

### Calls Don't Hang Up

The current configuration uses:
- `Application: Wait` with duration parameter
- Automatic hangup after wait completes

If calls persist, check:
```bash
asterisk -rx "core show channels"
asterisk -rx "channel request hangup all"
```

### Permission Errors

```bash
# Ensure proper ownership
sudo chown -R asterisk:asterisk /var/spool/asterisk/
sudo chown -R asterisk:asterisk /var/log/asterisk/
```

---

## 🔒 Firewall Configuration

```bash
# Allow SIP signaling
sudo ufw allow 5060/udp

# Allow RTP media
sudo ufw allow 10000:20000/udp

# Enable firewall
sudo ufw enable
```

---

## 📈 Scaling & Performance

### High Volume Dialing

For large campaigns (100+ simultaneous calls):

1. Increase Asterisk max calls:
```bash
# Edit /etc/asterisk/asterisk.conf
maxcalls = 500
maxload = 10.0
```

2. Adjust system limits:
```bash
# Edit /etc/security/limits.conf
asterisk soft nofile 10000
asterisk hard nofile 20000
```

3. Restart Asterisk:
```bash
systemctl restart asterisk
```

### Call Rate Limiting

Adjust delay between calls in the script:
```python
dialer.dial_list(calls, delay_between_calls=5)  # 5 seconds between calls
```

---

## 📝 CSV File Format

Format: `destination;caller_id;duration`

Example:
```csv
442080725001;447985019847;5
442080725010;447819001928;10
442080725002;442080725111;15
447123456789;447987654321;20
```

- **destination**: Phone number to dial
- **caller_id**: Caller ID to present
- **duration**: Call duration in seconds

---

## 🔄 Scheduled Campaigns

Use cron for scheduled dialing:

```bash
# Edit crontab
crontab -e

# Example: Daily at 9 AM
0 9 * * * /usr/bin/python3 /root/autodialer.py <<< "1
/root/calls.csv
2"

# Example: Every hour
0 * * * * /usr/bin/python3 /root/autodialer.py <<< "1
/root/calls.csv
2"
```

---

## 🆘 Support Commands

### Restart Everything
```bash
systemctl restart asterisk
sleep 5
asterisk -rx "pjsip show registrations"
```

### Stop All Calls
```bash
asterisk -rx "channel request hangup all"
```

### Clear Call Queue
```bash
rm /var/spool/asterisk/outgoing/*.call
```

### Check Asterisk Status
```bash
systemctl status asterisk
asterisk -rx "core show version"
asterisk -rx "pjsip show endpoints"
```

---

## 📋 System Requirements

- **OS**: Ubuntu 20.04 / 22.04 / 24.04
- **RAM**: Minimum 2GB (4GB+ for high volume)
- **CPU**: 2+ cores recommended
- **Disk**: 10GB+ free space
- **Network**: Stable internet connection, open UDP ports

---

## ⚡ Quick Reference

| Task | Command |
|------|---------|
| Start dialer | `python3 /root/autodialer.py` |
| Monitor calls | `asterisk -rvvvv` |
| Check registration | `asterisk -rx "pjsip show registrations"` |
| View logs | `tail -f /var/log/asterisk/autodialer.log` |
| Restart Asterisk | `systemctl restart asterisk` |
| Stop all calls | `asterisk -rx "channel request hangup all"` |

---

## 🎯 Features

✅ Custom Caller ID per call  
✅ Custom duration per call  
✅ Batch processing from CSV  
✅ No duplicate calls  
✅ Automatic hangup after duration  
✅ Detailed logging  
✅ Registration retry logic  
✅ Call archiving  

---

## 📄 License

This is open-source software. Use at your own risk.

---

## ⚠️ Legal Notice

Ensure you have proper authorization to place calls to all destinations.
Comply with local telecommunications regulations and anti-spam laws.
This software is for legitimate business use only.

---

**Version**: 2.0 (Working)  
**Last Updated**: January 2026  
**Tested On**: Ubuntu 24.04 with Asterisk 20.17.0
