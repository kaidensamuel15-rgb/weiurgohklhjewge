#!/usr/bin/env python3
"""
Asterisk Auto-Dialer Script
WORKING VERSION - Places single calls with custom CLI and duration
"""

import os
import time
import csv
import pwd
import grp
from datetime import datetime
from pathlib import Path

# Configuration
CALL_FILE_DIR = "/tmp/asterisk_calls"
ASTERISK_SPOOL = "/var/spool/asterisk/outgoing"
CALL_LOG = "/var/log/asterisk/autodialer.log"

class AutoDialer:
    def __init__(self):
        self.call_file_dir = Path(CALL_FILE_DIR)
        self.asterisk_spool = Path(ASTERISK_SPOOL)
        self.call_log = Path(CALL_LOG)
        
        # Get asterisk user UID/GID
        try:
            self.asterisk_uid = pwd.getpwnam('asterisk').pw_uid
            self.asterisk_gid = grp.getgrnam('asterisk').gr_gid
        except KeyError:
            print("Warning: asterisk user not found, using root")
            self.asterisk_uid = 0
            self.asterisk_gid = 0
        
        # Create temp directory if it doesn't exist
        self.call_file_dir.mkdir(parents=True, exist_ok=True)
        
    def log(self, message):
        """Log message to console and file"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_msg = f"[{timestamp}] {message}"
        print(log_msg)
        
        try:
            with open(self.call_log, 'a') as f:
                f.write(log_msg + "\n")
        except Exception as e:
            print(f"Warning: Could not write to log file: {e}")
    
    def create_call_file(self, destination, cli, duration, priority=0):
        """
        Create an Asterisk call file - uses direct PJSIP channel
        
        Args:
            destination: Phone number to dial
            cli: Caller ID to present
            duration: Call duration in seconds
            priority: Lower number = higher priority (default: 0)
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        filename = f"call_{timestamp}_{destination}.call"
        temp_file = self.call_file_dir / filename
        
        # Call file content - Direct PJSIP channel to avoid duplicate calls
        call_content = f"""Channel: PJSIP/{destination}@parked-endpoint
Callerid: "{cli}" <{cli}>
MaxRetries: 0
WaitTime: {duration}
Application: Wait
Data: {duration}
Archive: yes
"""
        
        with open(temp_file, 'w') as f:
            f.write(call_content)
        
        # Set permissions and ownership
        os.chmod(temp_file, 0o644)
        os.chown(temp_file, self.asterisk_uid, self.asterisk_gid)
        
        self.log(f"Created call file: {filename} | Dest: {destination} | CLI: {cli} | Duration: {duration}s")
        
        return temp_file
    
    def queue_call(self, call_file_path, delay=0):
        """
        Move call file to Asterisk spool directory to initiate call
        
        Args:
            call_file_path: Path to the call file
            delay: Seconds to wait before moving to spool (default: 0)
        """
        if delay > 0:
            self.log(f"Waiting {delay} seconds before queuing call...")
            time.sleep(delay)
        
        # Move to Asterisk spool directory
        destination = self.asterisk_spool / call_file_path.name
        
        try:
            os.rename(call_file_path, destination)
            # Ensure ownership is correct in spool directory too
            os.chown(destination, self.asterisk_uid, self.asterisk_gid)
            self.log(f"Queued call: {call_file_path.name}")
            return True
        except Exception as e:
            self.log(f"ERROR queuing call {call_file_path.name}: {e}")
            return False
    
    def dial_from_csv(self, csv_file, delay_between_calls=2):
        """
        Dial numbers from a CSV file
        
        CSV format: destination;cli;duration
        Example: 442080725001;447985019847;5
        """
        self.log(f"Starting auto-dialer from CSV: {csv_file}")
        
        try:
            with open(csv_file, 'r') as f:
                reader = csv.reader(f, delimiter=';')
                call_count = 0
                
                for row in reader:
                    if len(row) < 3:
                        self.log(f"WARNING: Skipping invalid row: {row}")
                        continue
                    
                    destination = row[0].strip()
                    cli = row[1].strip()
                    duration = int(row[2].strip())
                    
                    # Create call file
                    call_file = self.create_call_file(destination, cli, duration)
                    
                    # Queue the call
                    if self.queue_call(call_file, delay=delay_between_calls if call_count > 0 else 0):
                        call_count += 1
                
                self.log(f"Completed: {call_count} calls queued")
                return call_count
                
        except FileNotFoundError:
            self.log(f"ERROR: CSV file not found: {csv_file}")
            return 0
        except Exception as e:
            self.log(f"ERROR processing CSV: {e}")
            return 0
    
    def dial_single(self, destination, cli, duration):
        """
        Dial a single number immediately
        
        Args:
            destination: Phone number to dial
            cli: Caller ID to present
            duration: Call duration in seconds
        """
        self.log(f"Dialing single call: {destination}")
        call_file = self.create_call_file(destination, cli, duration)
        return self.queue_call(call_file)
    
    def dial_list(self, call_list, delay_between_calls=2):
        """
        Dial a list of calls
        
        Args:
            call_list: List of tuples [(destination, cli, duration), ...]
            delay_between_calls: Seconds between each call
        """
        self.log(f"Starting batch dial: {len(call_list)} calls")
        
        call_count = 0
        for i, (destination, cli, duration) in enumerate(call_list):
            call_file = self.create_call_file(destination, cli, duration)
            
            delay = delay_between_calls if i > 0 else 0
            if self.queue_call(call_file, delay=delay):
                call_count += 1
        
        self.log(f"Completed batch: {call_count} calls queued")
        return call_count


def main():
    """Main function with example usage"""
    dialer = AutoDialer()
    
    print("\n" + "="*50)
    print("Asterisk Auto-Dialer")
    print("="*50 + "\n")
    
    print("Choose an option:")
    print("1. Dial from CSV file")
    print("2. Dial single number")
    print("3. Dial example batch")
    print("4. Exit")
    
    choice = input("\nEnter choice (1-4): ").strip()
    
    if choice == "1":
        csv_file = input("Enter CSV file path: ").strip()
        delay = input("Delay between calls in seconds (default: 2): ").strip()
        delay = int(delay) if delay else 2
        dialer.dial_from_csv(csv_file, delay_between_calls=delay)
        
    elif choice == "2":
        destination = input("Enter destination number: ").strip()
        cli = input("Enter caller ID: ").strip()
        duration = int(input("Enter call duration (seconds): ").strip())
        dialer.dial_single(destination, cli, duration)
        
    elif choice == "3":
        # Example batch based on your numbers
        calls = [
            ("442080725001", "447985019847", 5),
            ("442080725010", "447819001928", 5),
            ("442080725002", "442080725111", 5),
        ]
        dialer.dial_list(calls, delay_between_calls=3)
        
    else:
        print("Exiting...")


if __name__ == "__main__":
    main()
